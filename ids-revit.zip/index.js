import * as fs from "fs";
import * as OBC from "@thatopen/components";
import { ifcRevitTypeMapping, ifcClassMapping, ifcRevitExportMapping } from "./mappings.js";

const components = new OBC.Components();
const ids = components.get(OBC.IDSSpecifications);

const convertIdsParameters = () => {
  const parameters = [];
  const sets = [];
  for (const [, spec] of ids.list) {
    for (const req of spec.requirements) {
      if (req.facetType !== "Property") continue;
      const { dataType, baseName } = req;
      const revitType = ifcRevitTypeMapping[dataType];
      if (baseName.type !== "simple" || !revitType) continue;
      const { parameter: propName } = baseName;
      const existingProp = parameters.find(({ name }) => name === propName);
      if (existingProp) continue;
      const sharedParameter = {
        param: "PARAM",
        guid: crypto.randomUUID(),
        name: propName,
        dataType: revitType,
        dataCategory: "",
        group: 1,
        visible: 1,
        description: "",
        userModifiable: 1,
        hideWhenNoValue: 0,
      }
      parameters.push(sharedParameter);
    }

    const elements = [];
    for (const app of spec.applicability) {
      if (app.facetType !== "Entity") continue;
      const { name: entityData } = app;
      if (entityData.type !== "simple") continue;
      const entity = ifcClassMapping[entityData.parameter];
      if (!entity) continue;
      elements.push(entity);
    }

    if (elements.length === 0) continue;

    for (const req of spec.requirements) {
      if (req.facetType !== "Property") continue;
      const { dataType, propertySet, baseName } = req;
      const exportType = ifcRevitExportMapping[dataType];
      if (propertySet.type !== "simple" || baseName.type !== "simple" || !exportType) continue;
      const { parameter: psetName } = propertySet;
      const { parameter: propName } = baseName;
      let set = sets.find(({ name }) => name === psetName);
      if (!set) {
        set = { name: psetName, elements, props: [] };
        sets.push(set);
      }
      const prop = {
        nameInIfc: propName,
        type: exportType,
        revitName: propName,
      }
      set.props.push(prop);
    }
  }

  const sharedParamsLines = [];
  for (const param of parameters) {
    const values = Object.values(param);
    sharedParamsLines.push(values.join("\t"));
  }

  const sharedParamsText = `# This is a Revit shared parameter file.
# Do not edit manually.
*META	VERSION	MINVERSION
META	2	1
*GROUP	ID	NAME
GROUP	1	IFC Parameters
*PARAM	GUID	NAME	DATATYPE	DATACATEGORY	GROUP	VISIBLE	DESCRIPTION	USERMODIFIABLE	HIDEWHENNOVALUE
${sharedParamsLines.join("\n")}`;

  const sharedParamsFileExists = fs.existsSync("./SharedParameters.txt");
  if (sharedParamsFileExists) fs.rmSync("./SharedParameters.txt");
  fs.writeFileSync("./SharedParameters.txt", sharedParamsText);

  const psetLines = [];
  for (const set of sets) {
    const { name, elements, props } = set;
    const psetLine = `PropertySet:\t${name}\tI\t${elements.join(",")}`;
    const propLines = [];
    for (const prop of props) {
      const { revitName, type, nameInIfc } = prop;
      let propLine = `\t${nameInIfc}\t${type}`;
      if (revitName) propLine += `\t${revitName}`;
      propLines.push(propLine);
    }
    const line = `${psetLine}\n${propLines.join("\n")}`;
    psetLines.push(line);
  }

  const userDefinedPsetsText = psetLines.join("\n");
  const psetsFileExists = fs.existsSync("./UserDefinedPsets.txt");
  if (psetsFileExists) fs.rmSync("./UserDefinedPsets.txt");
  fs.writeFileSync("./UserDefinedPsets.txt", userDefinedPsetsText);

}

const requirements = fs.readFileSync("./requirements.ids", "utf8");
ids.load(requirements);

convertIdsParameters()